﻿Imports System.Runtime.InteropServices
Imports Inventor

<ComVisible(True)>
<Guid("4404a1c4-fbf5-49cf-9715-43eeac14e185")>
Public Interface IAutomacaoExportacaoDXF
    Sub ExportarDXFs()
End Interface

<ComVisible(True)>
<Guid("00ac393f-46d9-4ff5-89ef-75b533f97f11")>
<ClassInterface(ClassInterfaceType.None)>
Public Class AutomacaoExportacaoDXF
    Implements IAutomacaoExportacaoDXF

    Private ReadOnly _app As Inventor.Application

    Public Sub New(app As Inventor.Application)
        _app = app
    End Sub

    Public Sub ExportarDXFs() Implements IAutomacaoExportacaoDXF.ExportarDXFs
        Dim exportador As New ExportadorDeDXF(_app)
        exportador.ExecutarExportacao()
    End Sub
End Class
