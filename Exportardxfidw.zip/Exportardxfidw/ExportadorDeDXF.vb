﻿Imports System.Reflection
Imports Inventor
Imports IO = System.IO

Public Class ExportadorDeDXF
    Private ReadOnly _app As Inventor.Application
    Private _regraExecutada As Boolean = False

    Public Sub New(app As Inventor.Application)
        _app = app
    End Sub

    Public Sub ExecutarExportacao()
        If _regraExecutada Then Return
        _regraExecutada = True

        Dim tempFilePath As String = Nothing

        Try
            Dim codigoIlogic As String = LerRegraIncorporada("ExportarDXF")
            If String.IsNullOrWhiteSpace(codigoIlogic) Then Return

            Dim doc As Document = _app.ActiveDocument
            If doc Is Nothing Then Return

            Dim iLogicAddIn As ApplicationAddIn = _app.ApplicationAddIns.ItemById("{3BDD8D79-2179-4B11-8A5A-257B1C0263AC}")
            If iLogicAddIn Is Nothing Then Return
            If Not iLogicAddIn.Activated Then iLogicAddIn.Activate()

            Dim iLogicAuto As Object = iLogicAddIn.Automation
            If iLogicAuto Is Nothing Then Return

            tempFilePath = IO.Path.Combine(IO.Path.GetTempPath(), "RegraExportacaoDXFTemp.ilogic")
            IO.File.WriteAllText(tempFilePath, codigoIlogic)

            Dim metodo As MethodInfo = iLogicAuto.GetType().GetMethod("RunExternalRule", New Type() {GetType(Document), GetType(String)})
            If metodo Is Nothing Then Return

            metodo.Invoke(iLogicAuto, New Object() {doc, tempFilePath})
            doc.Save2(True)

        Catch
            ' Silencioso
        Finally
            If Not String.IsNullOrEmpty(tempFilePath) AndAlso IO.File.Exists(tempFilePath) Then
                Try : IO.File.Delete(tempFilePath) : Catch : End Try
            End If
        End Try
    End Sub

    Private Function LerRegraIncorporada(parteDoNome As String) As String
        Dim assembly As Assembly = Assembly.GetExecutingAssembly()
        Dim recursos() As String = assembly.GetManifestResourceNames()

        Dim nomeCompleto As String = recursos.FirstOrDefault(
            Function(r) r.IndexOf(parteDoNome, StringComparison.OrdinalIgnoreCase) >= 0
        )

        If String.IsNullOrEmpty(nomeCompleto) Then Return Nothing

        Using stream As IO.Stream = assembly.GetManifestResourceStream(nomeCompleto)
            If stream Is Nothing Then Return Nothing
            Using reader As New IO.StreamReader(stream)
                Return reader.ReadToEnd()
            End Using
        End Using
    End Function
End Class

