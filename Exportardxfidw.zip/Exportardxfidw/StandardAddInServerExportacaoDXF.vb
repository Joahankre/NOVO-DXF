﻿Imports System.Drawing
Imports System.IO
Imports System.Reflection
Imports System.Runtime.InteropServices
Imports System.Windows.Forms
Imports Inventor
Imports stdole

<ComVisible(True)>
<Guid("8776e987-d298-414a-b9bf-aa412f3928e6")> ' Mantenha o GUID do seu AddIn
Public Class StandardAddInServerExportacaoDXF
    Implements ApplicationAddInServer

    Private _inventorApp As Inventor.Application
    Private _automacaoExport As AutomacaoExportacaoDXF
    Private botaoExportar As ButtonDefinition

    Public ReadOnly Property Automation As Object Implements ApplicationAddInServer.Automation
        Get
            Return _automacaoExport
        End Get
    End Property

    Public Sub Activate(ByVal addInSiteObject As ApplicationAddInSite, ByVal firstTime As Boolean) Implements ApplicationAddInServer.Activate
        _inventorApp = addInSiteObject.Application
        _automacaoExport = New AutomacaoExportacaoDXF(_inventorApp)

        If firstTime Then
            Try
                Dim controlDefs As ControlDefinitions = _inventorApp.CommandManager.ControlDefinitions

                ' Obter assembly atual
                Dim assembly As Assembly = Assembly.GetExecutingAssembly()

                ' DEBUG: lista todos os recursos embutidos para validar o nome dos ícones
                Dim recursos = assembly.GetManifestResourceNames()
                'MessageBox.Show("Recursos embutidos encontrados:" & vbCrLf & String.Join(vbCrLf, recursos), "Debug Recursos")

                ' Ajuste o namespace e nome do recurso conforme sua estrutura real no projeto
                Dim recursoIconePequeno As String = "ExportadorDeDXF.16x16.ico" ' Exemplo: "SeuNamespace.ExportadorDeDXF.16x16.ico"
                Dim recursoIconeGrande As String = "ExportadorDeDXF.32x32.ico"

                Dim smallPicture As IPictureDisp = Nothing
                Dim largePicture As IPictureDisp = Nothing

                ' Carregar ícone pequeno
                Using streamPequeno As Stream = assembly.GetManifestResourceStream(recursoIconePequeno)
                    If streamPequeno IsNot Nothing Then
                        smallPicture = IconToIPictureDisp(New Icon(streamPequeno))
                    Else
                        'MessageBox.Show("Ícone pequeno não encontrado: " & recursoIconePequeno, "Erro Ícone")
                    End If
                End Using

                ' Carregar ícone grande
                Using streamGrande As Stream = assembly.GetManifestResourceStream(recursoIconeGrande)
                    If streamGrande IsNot Nothing Then
                        largePicture = IconToIPictureDisp(New Icon(streamGrande))
                    Else
                        'MessageBox.Show("Ícone grande não encontrado: " & recursoIconeGrande, "Erro Ícone")
                    End If
                End Using

                ' Tenta recuperar o botão, senão cria novo
                Try
                    botaoExportar = DirectCast(controlDefs.Item("MyCompany_ExportarDXFs"), ButtonDefinition)
                    'MessageBox.Show("Botão já existente encontrado.", "Debug Botão")
                Catch
                    botaoExportar = controlDefs.AddButtonDefinition(
                        "Exportar" & vbCrLf & "DXFs",
                        "MyCompany_ExportarDXFs",
                        CommandTypesEnum.kShapeEditCmdType,
                        "{8776e987-d298-414a-b9bf-aa412f3928e6}",
                        "Executa regra iLogic para exportar DXFs",
                        "Exportar DXFs",
                        smallPicture,
                        largePicture)
                    'MessageBox.Show("Botão criado.", "Debug Botão")
                End Try

                ' Adiciona o evento OnExecute
                AddHandler botaoExportar.OnExecute, AddressOf BotaoExportar_OnExecute

                ' Acessa a Ribbon Drawing e aba id_TabTools
                Dim ribbon As Ribbon = _inventorApp.UserInterfaceManager.Ribbons("Drawing")
                Dim tab As RibbonTab = ribbon.RibbonTabs("id_TabTools")

                ' Tenta recuperar o painel, ou cria novo
                Dim painel As RibbonPanel
                Try
                    painel = tab.RibbonPanels.Item("PainelExportarDXF")
                    'MessageBox.Show("Painel existente encontrado.", "Debug Painel")
                Catch
                    painel = tab.RibbonPanels.Add("Exportação DXF", "PainelExportarDXF", "MyCompany.PanelExportGUID")
                    ' MessageBox.Show("Painel criado.", "Debug Painel")
                End Try

                ' Verifica se o botão já existe no painel
                Dim botaoExiste As Boolean = painel.CommandControls.Cast(Of CommandControl)().Any(Function(c) c.ControlDefinition.InternalName = "MyCompany_ExportarDXFs")

                If Not botaoExiste Then
                    painel.CommandControls.AddButton(botaoExportar, True)
                    ' MessageBox.Show("Botão adicionado ao painel.", "Debug Painel")
                Else
                    'MessageBox.Show("Botão já está no painel.", "Debug Painel")
                End If

            Catch ex As Exception
                'MessageBox.Show("Erro ao criar botão de exportação: " & ex.Message, "Erro")
            End Try
        End If
    End Sub

    Public Sub Deactivate() Implements ApplicationAddInServer.Deactivate
        _inventorApp = Nothing
        _automacaoExport = Nothing
    End Sub

    Public Sub ExecuteCommand(commandID As Integer) Implements ApplicationAddInServer.ExecuteCommand
        ' Não utilizado
    End Sub

    Private Sub BotaoExportar_OnExecute(Context As NameValueMap)
        Try
            _automacaoExport.ExportarDXFs()
        Catch ex As Exception
            'MessageBox.Show("Erro ao exportar DXFs: " & ex.Message, "Erro Exportação")
        End Try
    End Sub

    ' Conversão de Icon para IPictureDisp (necessário para ícones no Inventor)
    Private Function IconToIPictureDisp(icon As Icon) As IPictureDisp
        Dim bmp As Bitmap = icon.ToBitmap()
        Return AxHostConverter.ImageToPictureDisp(bmp)
    End Function

    Private Class AxHostConverter
        Inherits AxHost
        Private Sub New()
            MyBase.New(String.Empty)
        End Sub

        Public Shared Function ImageToPictureDisp(image As System.Drawing.Image) As IPictureDisp
            Return CType(GetIPictureDispFromPicture(image), IPictureDisp)
        End Function
    End Class
End Class

